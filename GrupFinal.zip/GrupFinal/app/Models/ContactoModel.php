<?php

namespace App\Models;

use CodeIgniter\Model;

class ContactoModel extends Model
{
    protected $table      = 'contactos';
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['nombre', 'apellido', 'email', 'telefono'];

    protected $useTimestamps = false;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = [
        'nombre' => 'required',
        'email' => 'required|valid_email',
        'telefono' => 'required|regex_match[[(][0-9]{3}[)] [0-9]{3} [0-9]{4}]',
    ];
    protected $validationMessages = [
        'nombre' => [
            'required' => 'nombre es requerido',
        ],
        'email' => [
            'required' => 'email es requerido',
        ],
        'telefono' => [
            'required' => 'telefono es requerido',
            'regex_match' => 'telefono debe de conincidir con (###) ### ####',
        ],
    ];
    protected $skipValidation     = false;
}