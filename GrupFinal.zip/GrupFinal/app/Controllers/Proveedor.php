<?php

namespace App\Controllers;

use App\Models\ContactoModel;

class Proveedor extends BaseController
{
    public function index()
    {
        $model = model(ContactoModel::class);

        $buscarPor = $this->request->getVar('buscar_por') ?? '';
        $buscar = $this->request->getVar('buscar') ?? '';

        if (!empty($buscarPor) && !empty($buscar)) {

            $contactos = $model->select('id, titulo, editorial, isbn')
                ->where([$buscarPor => $buscar])
                ->paginate(10);

            $data = [
                'contactos' => $contactos,
                'pager' => $model->pager,
            ];
    
            return view('contactos/index', $data);

        } else {

            $contactos = $model->paginate(10);
            $data = [
                'contactos' => $contactos,
                'pager' => $model->pager,
            ];
    
            return view('contactos/index', $data);

        }
    }

    public function crear() {
        return view('contactos/agregar');
    }

    public function guardar() {

        $contacto = model(ContactoModel::class);

        $nombre = $this->request->getPost('nombre');
        $apellido = $this->request->getPost('apellido');
        $email = $this->request->getPost('email');
        $telefono = $this->request->getPost('telefono');

        $datos = [
            'nombre' => $nombre,
            'apellido' => $apellido,
            'email' => $email,
            'telefono' => $telefono,
        ];

        if ($contacto->save($datos) === false) {
            return view('contactos/agregar', ['errores' => $contacto->errors()]);
        } else {
            return redirect()->to('/contactos/agregar')->with('mensaje', 'Datos guardados');
        }

    }

    public function editar($id) {

        $contacto = model(ContactoModel::class);
        $datos = $contacto->find($id);

        return view('contactos/editar', ['contacto' => $datos]);

    }

    public function actualizar($id) {

        $contacto = model(ContactoModel::class);

        $nombre = $this->request->getPost('nombre');
        $apellido = $this->request->getPost('apellido');
        $email = $this->request->getPost('email');
        $telefono = $this->request->getPost('telefono');

        $datos = [
            'id' => $id,
            'nombre' => $nombre,
            'apellido' => $apellido,
            'email' => $email,
            'telefono' => $telefono,
        ];

        if ($contacto->update($id, $datos) === false) {
            return view('contactos/editar', ['errores' => $contacto->errors(), 'contacto' => $datos]);
        } else {
            return redirect()->to('/contactos')->with('mensaje', 'Datos actualizados');
        }

    }

    public function eliminar($id) {

        $contacto = model(ContactoModel::class);
        $datos = $contacto->delete($id);

        return redirect()->to('/contactos')->with('mensaje', 'Datos eliminados');

    }
}
